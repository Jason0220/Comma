Release Notes:

1. 合入穿透式心率电平控制代码。
